/*
 * interrupt.c -
 */
#include <types.h>
#include <interrupt.h>
#include <segment.h>
#include <hardware.h>
#include <io.h>

#include <zeos_interrupt.h>

Gate idt[IDT_ENTRIES];
Register    idtR;

char char_map[] =
{
  '\0','\0','1','2','3','4','5','6',
  '7','8','9','0','\'','�','\0','\0',
  'q','w','e','r','t','y','u','i',
  'o','p','`','+','\0','\0','a','s',
  'd','f','g','h','j','k','l','�',
  '\0','�','\0','�','z','x','c','v',
  'b','n','m',',','.','-','\0','*',
  '\0','\0','\0','\0','\0','\0','\0','\0',
  '\0','\0','\0','\0','\0','\0','\0','7',
  '8','9','-','4','5','6','+','1',
  '2','3','0','\0','\0','\0','<','\0',
  '\0','\0','\0','\0','\0','\0','\0','\0',
  '\0','\0'
};

void setInterruptHandler(int vector, void (*handler)(), int maxAccessibleFromPL)
{
  /***********************************************************************/
  /* THE INTERRUPTION GATE FLAGS:                          R1: pg. 5-11  */
  /* ***************************                                         */
  /* flags = x xx 0x110 000 ?????                                        */
  /*         |  |  |                                                     */
  /*         |  |   \ D = Size of gate: 1 = 32 bits; 0 = 16 bits         */
  /*         |   \ DPL = Num. higher PL from which it is accessible      */
  /*          \ P = Segment Present bit                                  */
  /***********************************************************************/
  Word flags = (Word)(maxAccessibleFromPL << 13);
  flags |= 0x8E00;    /* P = 1, D = 1, Type = 1110 (Interrupt Gate) */

  idt[vector].lowOffset       = lowWord((DWord)handler);
  idt[vector].segmentSelector = __KERNEL_CS;
  idt[vector].flags           = flags;
  idt[vector].highOffset      = highWord((DWord)handler);
}

void setTrapHandler(int vector, void (*handler)(), int maxAccessibleFromPL)
{
  /***********************************************************************/
  /* THE TRAP GATE FLAGS:                                  R1: pg. 5-11  */
  /* ********************                                                */
  /* flags = x xx 0x111 000 ?????                                        */
  /*         |  |  |                                                     */
  /*         |  |   \ D = Size of gate: 1 = 32 bits; 0 = 16 bits         */
  /*         |   \ DPL = Num. higher PL from which it is accessible      */
  /*          \ P = Segment Present bit                                  */
  /***********************************************************************/
  Word flags = (Word)(maxAccessibleFromPL << 13);

  //flags |= 0x8F00;    /* P = 1, D = 1, Type = 1111 (Trap Gate) */
  /* Changed to 0x8e00 to convert it to an 'interrupt gate' and so
     the system calls will be thread-safe. */
  flags |= 0x8E00;    /* P = 1, D = 1, Type = 1110 (Interrupt Gate) */

  idt[vector].lowOffset       = lowWord((DWord)handler);
  idt[vector].segmentSelector = __KERNEL_CS;
  idt[vector].flags           = flags;
  idt[vector].highOffset      = highWord((DWord)handler);
}

/* INTERRUPT ROUTINES GO HERE */

void clock_routine ()
{
    inc_zeos_ticks();
    zeos_show_clock();
}

void keyboard_routine ()
{
    unsigned char value = inb(0x60);
    if(((value & (1 << 7)) == 0) && (char_map[value] == '\0')) printc_xy(10,10,'C');
    else if((value & (1 << 7)) == 0) printc_xy(10,10,char_map[value]);
}

/* SYS CALL ROUTINES GO HERE */
/* 1 - Check parameters
   2 - Copy data from/to user space if needed
   3 - Implement the requested service. For the I/O system calls, this requires calling the device
dependent routine
   4 - Return result
*/

int sys_write (int fd, char *buffer, int size)
{
    //Check if fd for writting is correct, in the delivery only 1 is correct
    int res = check_fd(fd,1);
    if(res < 0) return res;

    //Check if *buffer is not null
    if(buffer == NULL) return -14; // EFAULT -> bad address

    //Check if size is >= 0
    if(size < 0) return -22; //EINVAL -> invalid argument

    //Copying data from user space to kernel space
    char sys_buffer[size];
    res = copy_from_user(buffer,sys_buffer,size);
    if(res < 0) return res;

    //Implement the requested service. For the I/O system calls, this requires calling the device dependent routine
    return sys_write_console(sys_buffer,size);
}

int sys_gettime (void)
{
    return get_zeos_ticks();
}

/* HANDLER DECLARATIONS GO HERE */
/* just to trick compiler, these are implemented in entry.S */

void keyboard_handler();
void clock_handler();

void system_call_handler();

void setIdt()
{
  /* Program interrups/exception service routines */
  idtR.base  = (DWord)idt;
  idtR.limit = IDT_ENTRIES * sizeof(Gate) - 1;

  set_handlers();

  /* ADD INITIALIZATION CODE FOR INTERRUPT VECTOR */
  setInterruptHandler(33, keyboard_handler, 0);
  setInterruptHandler(32, clock_handler, 0);

  /* ADD INITIALIZATION CODE FOR SETTING ENTRY POINTS OF SYS CALLS */
  setTrapHandler(0x80, system_call_handler, 3);

  set_idt_reg(&idtR);
}
