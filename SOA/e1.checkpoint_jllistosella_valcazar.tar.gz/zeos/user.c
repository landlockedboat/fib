#include <libc.h>

char buff[24];

int pid;

int __attribute__ ((__section__(".text.main")))

main(void)
{
	// write test
	write(1,"\n",1);
	write(1,"Hello world!\n",13);
	perror();

	// perror test
	/*write(1,"\n",1);
	write(0,"asdf",4);
	perror();*/

	// gettime test
	/*write(1,"\n",1);
	char arr[10];
	int t = gettime();
	itoa(t,arr);
	write(1,arr,10);
	perror();*/

	while (1)
	{
	    // Uncomment to test infinitely
	    /*
	    t = gettime();
	    itoa(t,arr);
	    write(1,arr,10);
	    write(1,"\n",1);
	    */
	}
	return 0;
}
