/*
 * libc.c 
 */

#include <libc.h>

#include <types.h>

int errno;

void itoa(int a, char *b)
{
  int i, i1;
  char c;
  
  if (a==0) { b[0]='0'; b[1]=0; return ;}
  
  i=0;
  while (a>0)
  {
    b[i]=(a%10)+'0';
    a=a/10;
    i++;
  }
  
  for (i1=0; i1<i/2; i1++)
  {
    c=b[i1];
    b[i1]=b[i-i1-1];
    b[i-i1-1]=c;
  }
  b[i]=0;
}

int strlen(char *a)
{
  int i;
  
  i=0;
  
  while (a[i]!=0) i++;
  
  return i;
}

int err()
{
    return errno;
}

/* WRAPPERS FOR SYS CALLS GO HERE (I GUESS) */

/* Steps
   1 - Pass parameters from stack to registers
       Order (from left to right): ebx, ecx, edx, esi, edi
   2 - Put the identifier of the sys call in eax
   3 - Generate the trap (int 0x80)
   4 - Process the result and return
*/


int write (int fd, char * buffer, int size)
{
   /* SYS CALL ID = 4 */
   /* Parameter passing:
      eax = 4, ebx = fd, ecx = *buffer, edx = size
   */

   int res;

   /* It's done like this because otherwise optimization may fuck the stack if this function is inline */
   __asm__ __volatile__ (
   "int $0x80\n\t"
   : "=a" (res)
   : "b" (fd), "c" (buffer), "d" (size) , "a" (4));

   /* Process result */
   if(res >= 0) return res;
   else {
	errno = res * (-1);
	return -1;
   }
}

int gettime (void)
{
    /* SYS CALL ID = 10 */
    /* Parameter passing: 
       eax = 10
    */
    int res;
    __asm__ __volatile__ (
    "movl $0x0A, %%eax\n\t"
    "int $0x80\n\t"
    "mov %%eax, %0"
    : "=r" (res));

    /* Process result */
    return res;
}

/* SIMPLE PERROR FUNCTION */

/* Expand when necessary */

//9 ebadf, 13 eacces, 14 efault, 22 einval, 38 enosys, 

void perror(void)
{
    write(1,"\n",1);
    if(errno == 0) write(1,"No errors reported to errno\n",28);
    else {
        write(1,"ERROR: last syscall produced errno val: ",40);

        if(errno == 9) write(1,"9, EBADF -> bad file descriptor\n",32);
        if(errno == 13) write(1,"13, EACCES -> permission denied\n",32);
        if(errno == 14) write(1,"14, EFAULT -> bad address\n",26);
        if(errno == 22) write(1,"22, EINVAL -> invalid argument\n",31);
        if(errno == 38) write(1,"38, ENOSYS -> function not implemented\n",39);
    }
    write(1,"\n",1);
}

