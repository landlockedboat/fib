#include <libc.h>

char buff[24];

int pid;

int __attribute__ ((__section__(".text.main")))

main(void)
{
    //fork and exit test

    write(1,"\n",1);

    int pid = fork();
    if(pid >= 0)
    {
        //child
        if(pid == 0)
        {
            write(1,"I am the child with PID: ",25);
            char arr[10];
            int p = getpid();
            itoa(p,arr);
            write(1,arr,10);
            write(1,"\n",1);

	    exit();
        }
        //parent
        else
        {
            write(1,"I am the parent with PID: ",26);
            char arr[10];
            int p = getpid();
            itoa(p,arr);
            write(1,arr,10);
            write(1,"\n",1);
        }
    }
    write(1,"This is print only by the father\n",33);
    exit();

    //stats test

    /*struct stats s;
    struct stats *st = &s;
    int a = get_stats(1, st);

    char usr[10];
    char sys[10];
    char ela[10];
    itoa(st->user_ticks,usr);
    itoa(st->system_ticks,sys);
    itoa(st->elapsed_total_ticks,ela);

    write(1,"Stats\n",6);
    write(1,usr,10);
    write(1,"\n",1);
    write(1,sys,10);
    write(1,"\n",1);
    write(1,ela,10);
    write(1,"\n",1);

    int delay = 0;
    while(!delay)
    {
      if(gettime() >= 1000) delay = 1;
    }

    a = get_stats(1, st);

    itoa(st->user_ticks,usr);
    itoa(st->system_ticks,sys);
    itoa(st->elapsed_total_ticks,ela);

    write(1,"Stats\n",6);
    write(1,usr,10);
    write(1,"\n",1);
    write(1,sys,10);
    write(1,"\n",1);
    write(1,ela,10);
    write(1,"\n",1);*/

    while (1);
    return 0;
}
