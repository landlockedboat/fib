/*
 * sched.c - initializes struct for task 0 anda task 1
 */

#include <sched.h>
#include <mm.h>
#include <io.h>

#define DEFAULT_QUANTUM 100

/**
 * Container for the Task array and 2 additional pages (the first and the last one)
 * to protect against out of bound accesses.
 */
union task_union protected_tasks[NR_TASKS+2]
__attribute__((__section__(".data.task")));

union task_union *task = &protected_tasks[1]; /* == union task_union task[NR_TASKS] */

struct task_struct *list_head_to_task_struct(struct list_head *l)
{
  unsigned long task_struct_dir = (unsigned long)l & 0xfffff000;
  return task_struct_dir;
}

extern struct list_head blocked;

/* IDLE TASK GLOBAL VAR */

struct task_struct *idle_task=NULL;

/* FREEQUEUE DECLARATION */

struct list_head freequeue;

/* READYQUEUE DECLARATION */

struct list_head readyqueue;

/* INIT STATS */

void init_stats (struct stats *s)
{
  s->user_ticks = 0;
  s->system_ticks = 0;
  s->blocked_ticks = 0;
  s->ready_ticks = 0;
  s->elapsed_total_ticks = get_ticks();
  s->total_trans = 0;
  s->remaining_ticks = get_ticks();
}

/* get_DIR - Returns the Page Directory address for task 't' */
page_table_entry * get_DIR (struct task_struct *t) 
{
  return t->dir_pages_baseAddr;
}

/* get_PT - Returns the Page Table address for task 't' */
page_table_entry * get_PT (struct task_struct *t) 
{
  return (page_table_entry *)(((unsigned int)(t->dir_pages_baseAddr->bits.pbase_addr))<<12);
}


int allocate_DIR(struct task_struct *t) 
{
  int pos;

  pos = ((int)t-(int)task)/sizeof(union task_union);

  t->dir_pages_baseAddr = (page_table_entry*) &dir_pages[pos]; 

  return 1;
}

void cpu_idle(void)
{
  __asm__ __volatile__("sti": : :"memory");

  printk("Idle\n");

  while(1)
  {
    ;
  }
}

void init_idle (void)
{
  //take the first free task struct
  struct list_head *l = list_first(&freequeue);
  //delete the entry from the freequeue
  list_del(l);
  //get the task struct
  struct task_struct *ts = list_head_to_task_struct(l);
  //get the task union (whole page)
  union task_union *page = (union task_union*)ts;

  //Init
  ts->PID = 0;
  //Quantum
  ts->quantum = DEFAULT_QUANTUM;
  //Init stats
  init_stats(&ts->stats);

  //Allocate directory pages
  allocate_DIR(ts);

  //EXEC CONTEXT
  //store return adr in the stack (cpu_idle) (CAST?)
  page->stack[KERNEL_STACK_SIZE-1] = (unsigned long)&cpu_idle;

  //initial value of ebp when undoing dynamic link (0)
  page->stack[KERNEL_STACK_SIZE-2] = 0;

  //keep this last position as the top of the stack in the esp reg (CAST?)
  ts->kernel_esp = (unsigned long)&(page->stack[KERNEL_STACK_SIZE-2]);

  //attach to global variable
  idle_task = ts;
}

void init_task1(void)
{
  //take the first free task struct
  struct list_head *l = list_first(&freequeue);
  //delete the entry from the freequeue
  list_del(l);
  //get the task struct
  struct task_struct *ts = list_head_to_task_struct(l);
  //get the task union (whole page)
  union task_union *page = (union task_union*)ts;

  //Init
  ts->PID = 1;
  //Quantum
  ts->quantum = DEFAULT_QUANTUM;
  //Init stats
  init_stats(&ts->stats);

  //Allocate directory pages
  allocate_DIR(ts);

  //Allocate physical space to hold the user address space and add translation to page table
  set_user_pages(ts);

  //Update the TSS to make it point to the new_task system stack (CAST?)
  tss.esp0=(DWord)&(page->stack[KERNEL_STACK_SIZE]);

  //Set its page directory as the current page directory in the system
  set_cr3(ts->dir_pages_baseAddr);
}


void init_sched(void)
{
  init_freequeue();
  init_readyqueue();
}

/* INIT FREEQUEUE */

void init_freequeue(void)
{
  INIT_LIST_HEAD(&freequeue);

  // put all task structs inside
  for(int i = 0; i < NR_TASKS; ++i)
  {
    task[i].task.PID=-1;
    list_add_tail(&(task[i].task.list), &freequeue);
  }
}

/* INIT READYQUEUE */

void init_readyqueue(void)
{
  INIT_LIST_HEAD(&readyqueue);
}

struct task_struct* current()
{
  int ret_value;

  __asm__ __volatile__(
      "movl %%esp, %0"
      : "=g" (ret_value)
      );
  return (struct task_struct*)(ret_value&0xfffff000);
}

// ********************************************************************************************
// TASK SWITCH
// ********************************************************************************************
void inner_task_switch(union task_union* new)
{
  // 1)  Update the TSS to make it point to the new_task system stack
  tss.esp0=(DWord)&(new->stack[KERNEL_STACK_SIZE]);

  struct task_struct* new_struct = (unsigned long) new;
  // 2)  Change  the  user  address  space  by  updating  the  current  page  directory:  use  the  set_cr3
  // funtion to set the cr3 register to point to the page directory of the new_task.
  set_cr3(get_DIR(new_struct));

  // 3)  Store the current value of the EBP register in the PCB. EBP has the address of the current
  // system stack where the inner_task_switch routine begins (the dynamic link).
  __asm__ __volatile__ (
      "movl %%ebp, %0"
      : "=g" (current()->kernel_esp));

  // 4)  Change the current system stack by setting ESP register to point to the stored value in the new PCB.
  __asm__ __volatile__ (
      "movl %0, %%esp"
      :
      : "g" (new_struct->kernel_esp));

  // 5)  Restore the EBP register from the stack.
  __asm__ __volatile__ ("popl %ebp");

  // 6)  Return  to  the  routine  that  called  this  one  using  the  instruction RET (usually task_switch , but. . . ).
  __asm__ __volatile__("ret");
}

void task_switch(union task_union*t)
{
  __asm__ __volatile__ ( 
      "pushl %esi\n\t" 
      "pushl %edi\n\t" 
      "pushl %ebx" 
      );

  inner_task_switch(t);

  __asm__ __volatile__ ( 
      "popl %ebx\n\t" 
      "popl %edi\n\t" 
      "popl %esi" 
      );
}

// TASK SCHEDULING

int get_quantum (struct task_struct *t)
{
  return t->quantum;
}

void set_quantum (struct task_struct *t, int new_quantum)
{
  t->quantum = new_quantum;
}

void schedule()
{
  update_sched_data_rr();
  if(needs_sched())
  {
    update_process_state_rr(current(),&readyqueue);
    sched_next();
  }
}


void update_sched_data_rr()
{
  // Update the relevant information to take scheduling decisions
  --current()->quantum;
  current()->stats.remaining_ticks = current()->quantum;
}

int needs_sched()
{
  // returns: 1 if it is necessary to change the current process and 0
  // otherwise

  if(get_quantum(current()) > 0)
  {
    return 0;
  }

  if(!list_empty(&readyqueue))
  {
    return 1;
  }

  if(current() == idle_task)
  {
    return 0;
  }

  return 1;
}

void update_process_state_rr(struct task_struct *t, struct list_head *dest)
{
  // If current state: not running
  // delete process from its current queue

  if(dest == NULL)
  {
    // Add process to suitable queue
    list_del(&t->list);
    t->state = ST_RUN;
  }
  else
  {
    list_add_tail(&t->list, dest);
    if(dest!=&readyqueue) t->state = ST_BLOCKED;
    else
    {
      update_stats(&(t->stats.system_ticks), &(t->stats.elapsed_total_ticks));
      t->state = ST_READY;
    }
  }
}

void sched_next()
{
  // Select the next process to execute, extract it from the ready queue
  // and invoke the context switch process.

  struct task_struct *new;

  // If the list is empty, we jump to idle
  if(list_empty(&readyqueue))
  {
    new = idle_task;
  }
  else
  {
    new = list_head_to_task_struct(list_first(&readyqueue));
    // Set this process to ready and delete it from previous queues
    update_process_state_rr(new, NULL);
  }

  set_quantum(new, DEFAULT_QUANTUM);

  // Update stats
  update_stats(&(current()->stats.system_ticks), &(current()->stats));
  update_stats(&(new->stats.ready_ticks), &(new->stats));
  // Update total transitions
  ++new->stats.total_trans;

  task_switch(new);
}

void update_stats (unsigned long *ticks, struct stats *s)
{
  *ticks += get_ticks() - s->elapsed_total_ticks;
  s->elapsed_total_ticks = get_ticks();
}
