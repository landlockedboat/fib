/*
 * libc.c 
 */

#include <libc.h>

#include <types.h>

int errno;

void itoa(int a, char *b)
{
  int i, i1;
  char c;
  
  if (a==0) { b[0]='0'; b[1]=0; return ;}
  
  i=0;
  while (a>0)
  {
    b[i]=(a%10)+'0';
    a=a/10;
    i++;
  }
  
  for (i1=0; i1<i/2; i1++)
  {
    c=b[i1];
    b[i1]=b[i-i1-1];
    b[i-i1-1]=c;
  }
  b[i]=0;
}

int strlen(char *a)
{
  int i;
  
  i=0;
  
  while (a[i]!=0) i++;
  
  return i;
}

int err()
{
    return errno;
}

/* WRAPPERS FOR SYS CALLS GO HERE (I GUESS) */

/* Steps
   1 - Pass parameters from stack to registers
       Order (from left to right): ebx, ecx, edx, esi, edi
   2 - Put the identifier of the sys call in eax
   3 - Generate the trap (int 0x80)
   4 - Process the result and return
*/


int write (int fd, char * buffer, int size)
{
   /* SYS CALL ID = 4 */
   /* Parameter passing:
      eax = 4, ebx = fd, ecx = *buffer, edx = size
   */

   int res;

   /* It's done like this because otherwise optimization may fuck the stack if this function is inline */
   __asm__ __volatile__ (
   "int $0x80\n\t"
   : "=a" (res)
   : "b" (fd), "c" (buffer), "d" (size) , "a" (4));

   /* Process result */
   if(res >= 0) {
	errno = 0;
	return res;
   }
   else {
	errno = res * (-1);
	return -1;
   }
}

int gettime (void)
{
    /* SYS CALL ID = 10 */
    /* Parameter passing:
       eax = 10
    */
    int res;
    __asm__ __volatile__ (
    "movl $0x0A, %%eax\n\t"
    "int $0x80"
    : "=a" (res));

    /* Process result */
    errno = 0;
    return res;
}

int getpid (void)
{
    /* SYS CALL ID = 20 */
    /* Parameter passing:
       eax = 20
    */
    int res;
    __asm__ __volatile__ (
    "movl $0x14, %%eax\n\t"
    "int $0x80"
    : "=a" (res));

    /* Process result */
    errno = 0;
    return res;
}

int fork (void)
{
    /* SYS CALL ID = 2 */
    /* Parameter passing:
       eax = 2
    */
    int res;
    __asm__ __volatile__ (
    "movl $0x02, %%eax\n\t"
    "int $0x80"
    : "=a" (res));

    /* Process result */
    if(res >= 0) {
	errno = 0;
	return res;
    }
    else {
	errno = res * (-1);
	return -1;
    }
}

void exit (void)
{
    /* SYS CALL ID = 1 */
    /* Parameter passing:
       eax = 1
    */
    int res;
    __asm__ __volatile__ (
    "movl $0x01, %eax\n\t"
    "int $0x80"
    );
}

int get_stats (int pid, struct stats *st)
{
   /* SYS CALL ID = 35 */
   /* Parameter passing:
      eax = 35, ebx = pid, ecx = *st
   */
   int res;

   __asm__ __volatile__ (
   "int $0x80\n\t"
   : "=a" (res)
   : "b" (pid), "c" (st), "a" (35));

   /* Process result */
   if(res >= 0) {
        errno = 0;
        return res;
   }
   else {
        errno = res * (-1);
        return -1;
   }
}

/* SIMPLE PERROR FUNCTION */

/* Expand when necessary */

//9 ebadf, 11 eagain,  12 enomem, 13 eacces, 14 efault, 22 einval, 38 enosys, 

void perror(void)
{
    write(1,"\n",1);
    if(errno == 0) write(1,"No errors reported to errno\n",28);
    else {
        write(1,"ERROR: last syscall produced errno val: ",40);

	if(errno == 3) write(1,"3, ESRCH -> no such process\n", 28);
        if(errno == 9) write(1,"9, EBADF -> bad file descriptor\n",32);
        if(errno == 11) write(1,"11, EAGAIN -> try again\n",24);
	if(errno == 12) write(1,"12, ENOMEM -> out of memory\n",28);
        if(errno == 13) write(1,"13, EACCES -> permission denied\n",32);
        if(errno == 14) write(1,"14, EFAULT -> bad address\n",26);
        if(errno == 22) write(1,"22, EINVAL -> invalid argument\n",31);
        if(errno == 38) write(1,"38, ENOSYS -> function not implemented\n",39);
    }
    write(1,"\n",1);
}

