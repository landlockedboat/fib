/*
 * sys.c - Syscalls implementation
 */
#include <devices.h>

#include <utils.h>

#include <io.h>

#include <mm.h>

#include <mm_address.h>

#include <sched.h>

#define LECTURA 0
#define ESCRIPTURA 1

/* SYS CALL ROUTINES GO HERE */
/* 1 - Check parameters
   2 - Copy data from/to user space if needed
   3 - Implement the requested service. For the I/O system calls, this requires calling the device
   dependent routine
   4 - Return result
   */

int check_fd(int fd, int permissions)
{
  if (fd!=1) return -9; /*EBADF*/
  if (permissions!=ESCRIPTURA) return -13; /*EACCES*/
  return 0;
}

int sys_ni_syscall()
{
  return -38; /*ENOSYS*/
}


int sys_write (int fd, char *buffer, int size)
{
  //Check if fd for writting is correct, in the delivery only 1 is correct
  int res = check_fd(fd,ESCRIPTURA);
  if(res < 0) return res;

  //Check if *buffer is not null
  if(buffer == NULL) return -14; // EFAULT -> bad address

  //Check if size is >= 0
  if(size < 0) return -22; //EINVAL -> invalid argument

  //Copying data from user space to kernel space
  int bytes = size;
  char sys_buffer[size];
  res = copy_from_user(buffer,sys_buffer,size);
  if(res < 0) return res;

  //Implement the requested service. For the I/O system calls, this requires calling the device dependent routine
  return sys_write_console(sys_buffer,size);
}

extern int zeos_ticks;

int sys_gettime (void)
{
  return zeos_ticks;
}

int sys_getpid()
{
  return current()->PID;
}

int global_PID = 1000;

int ret_from_fork()
{
  return 0;
}

int sys_fork()
{
  //Return error if no task struct available
  if(list_empty(&freequeue)) return -12; //ENOMEM

  struct list_head *lh_child;
  struct task_struct *ts_child;
  union task_union *tu_child;

  //Get available task struct
  lh_child = list_first(&freequeue);
  //Delete entry from list
  list_del(lh_child);

  //Get task struct
  ts_child = list_head_to_task_struct(lh_child);
  //Get task union
  tu_child = (union task_union*)ts_child;


  /********** INHERIT SYSTEM DATA BEGIN ***************/
  //Copy parent's task union to the child
  copy_data(current(), tu_child, sizeof(union task_union));

  //Initialize a new directory to store child's process address space
  allocate_DIR(ts_child);

  //Search physical pages in which to map logical pages for data+stack 
  //of the child process (using  the  alloc_frames  function).
  //If  there  is  not  enough  free  pages,  an  error  will  be returned
  page_table_entry *child_page_table = get_PT(ts_child);
  int new_phys_page, page, i;

  //create temporal vector to see if we can really allocate all pages
  int array[NUM_PAG_DATA];
  for (page = 0; page < NUM_PAG_DATA; ++page)
  {
    int alloc = alloc_frame();
    if(alloc == -1)
    {
      //Can't allocate more, deallocate all
      int i;
      for (i = 0; i < page; ++i)
      {
        free_frame(array[i]);
      }
      //Free the task_struct
      list_add_tail(lh_child, &freequeue);
      //Return error
      return -11; //EAGAIN
    }
    array[page] = alloc;
  }
  //At this point we can allocate everything
  for (page = 0; page < NUM_PAG_DATA; ++page)
  {
    //Associate logical page 'page' with physcal page 'frame'
    set_ss_pag(child_page_table, PAG_LOG_INIT_DATA + page, array[page]);
  }
  /******** INHERIT SYSTEM DATA END **********/

  /******** INHERIT USER DATA BEGIN **********/
  //Copy system kernel and code page table entries from parent to child
  page_table_entry *parent_page_table = get_PT(current());
  for (page = 0; page < NUM_PAG_KERNEL; ++page)
  {
    //Create mapping from logical pages to physical frames
    set_ss_pag(child_page_table, page, get_frame(parent_page_table, page));
  }
  for (page = 0; page < NUM_PAG_CODE; ++page)
  {
    //Create mapping from logical pages to physical frames
    set_ss_pag(child_page_table, PAG_LOG_INIT_CODE + page, get_frame(parent_page_table, PAG_LOG_INIT_CODE + page));
  }

  //Copy parent's user data+stack to the child, using temporary logical address
  //This uses TOTAL_PAGES-1 as a temp logical page to map to
  for (page = NUM_PAG_KERNEL + NUM_PAG_CODE; page < (NUM_PAG_KERNEL + NUM_PAG_CODE + NUM_PAG_DATA); ++page)
  {
    //Map one child page to parent's adress space
    set_ss_pag(parent_page_table,NUM_PAG_DATA + page, get_frame(child_page_table, page));
    copy_data((void *)(page << 12), (void *)((NUM_PAG_DATA + page) << 12), PAGE_SIZE);
    del_ss_pag(parent_page_table, NUM_PAG_DATA + page);
  }

  //Deny access to child's memory space
  set_cr3(get_DIR(current()));
  /********* INHERIT USER DATA END ****************/

  //Assign PID
  tu_child->task.PID = global_PID;
  ++global_PID;

  /********* MODIFY REGISTERS BEGIN **************/
  //Modify registers of child that have to be different from parent
  DWord register_ebp;
  __asm__ __volatile__ (
      "movl %%ebp, %0"
      : "=g" (register_ebp)
      );
  //Get ebp and esp
  register_ebp=(register_ebp - (DWord)current()) + (DWord)(tu_child);
  tu_child->task.kernel_esp = register_ebp + sizeof(DWord);

  DWord temp_ebp = *(DWord *) register_ebp;
  //Prepare child stack for fork return (modify return address)
  tu_child->task.kernel_esp -= sizeof(DWord);
  *(DWord *)tu_child->task.kernel_esp = &ret_from_fork;
  //Modify ebp for the temporal ebp
  tu_child->task.kernel_esp -= sizeof(DWord);
  *(DWord *)tu_child->task.kernel_esp = temp_ebp;

  /********** MODIFY REGISTERS END **************/

  /********** SET INIT STATS BEGIN ***************/
  init_stats(&(tu_child->task.stats));
  /********** SET INIT STATS END *****************/

  //Queue child process into readyqueue
  tu_child->task.state = ST_READY;
  list_add_tail(&(tu_child->task.list), &readyqueue);

  //Finally return PID of child
  return tu_child->task.PID;
}

void sys_exit()
{
  page_table_entry * proc_page_table = get_PT(current());

  //Dealocate all physical frames and remove mapping with logical pages
  int page;
  for (page = 0; page < NUM_PAG_DATA; ++page)
  {
    //Mark frame as free
    free_frame(get_frame(proc_page_table, PAG_LOG_INIT_DATA + page));
    //Remove mapping from logical pages to physical frames
    del_ss_pag(proc_page_table, PAG_LOG_INIT_DATA + page);
  }

  //Set PID to something invalid
  current()->PID = -1;
  current()->quantum = 0;

  //Free task struct
  list_add_tail(&(current()->list), &freequeue);

  //Call scheduler for next process
  sched_next();
}

int sys_get_stats(int pid, struct stats *st)
{
  if(pid < 0) return -22; //EINVAL
  if(st == NULL) return -14; //EFAULT

  //Search for process
  int i;
  for (i = 0; i < NR_TASKS; ++i)
  {
    if(task[i].task.PID == pid)
    {
      task[i].task.stats.remaining_ticks = get_quantum(current());
      copy_to_user(&(task[i].task.stats), st, sizeof(struct stats));
      return 0;
    }
  }
  return -3; //ESRCH
}
